#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include <string.h>
#ifndef WIN32
#include <unistd.h>
#endif
#include <curl/curl.h>
int main(int argc, char **argv)
{

  char a[500];
  CURL *curl;
  CURLcode res;

	strcpy(a,"http://172.20.29.96:8080/json.htm?type=command&param=switchlight&idx=6&switchcmd=Off");
 

	curl = curl_easy_init();
	if(curl) {

	    curl_easy_setopt(curl, CURLOPT_URL, a);
	    curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
	    res = curl_easy_perform(curl);

	    if(res != CURLE_OK)
	      fprintf(stderr, "curl_easy_perform() failed: %s\n",
		      curl_easy_strerror(res));

	    curl_easy_cleanup(curl);
 	 }



 


}

