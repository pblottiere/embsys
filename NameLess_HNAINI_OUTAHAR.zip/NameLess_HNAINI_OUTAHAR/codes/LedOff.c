#include <gpio.h>
#include <stdio.h>


int main(void) {

int gpio = 27;
    //Turn led off 
    if(-1==GPIOExport(POUT))
	return(1);
    if (-1 == GPIODirection(POUT, OUT))
	return(2);
    if (-1 == GPIOWrite(POUT,0))
	return(3);

    printf("Raspberry Pi LED Off PIN = %d",gpio);
    
    return 0;

}
