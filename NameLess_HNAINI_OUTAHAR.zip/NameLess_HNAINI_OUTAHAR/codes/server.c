#include<stdio.h>
#include<string.h>    //strlen
#include<sys/socket.h>
#include<arpa/inet.h> //inet_addr
#include<unistd.h>    //write
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <gpio.h>



int childpid;

int main(int argc , char *argv[])
{ 
    int socket_desc , client_sock , c , read_size ;
    struct sockaddr_in server , client;
    char client_message[2000];
    char * msg;
    msg=(char *) malloc (256);
    char *args[2];
   
    //Create socket
    socket_desc = socket(AF_INET , SOCK_STREAM , 0);
    if (socket_desc == -1)
    {
        printf("Could not create socket");
    }
    puts("Socket created");
     
    //Prepare the sockaddr_in structure
    server.sin_family = AF_INET;
    server.sin_addr.s_addr = INADDR_ANY;
    server.sin_port = htons( 8181 );
     
    //Bind
    if( bind(socket_desc,(struct sockaddr *)&server , sizeof(server)) < 0)
    {
        //print the error message
        perror("bind failed. Error");
        return 1;
    }
    puts("bind done");
     
    //Listen
    listen(socket_desc , 3);
     
    //Accept and incoming connection
    puts("Waiting for incoming connections...");
    c = sizeof(struct sockaddr_in);
     
    //accept connection from an incoming client
  while(1){
    client_sock = accept(socket_desc, (struct sockaddr *)&client, (socklen_t*)&c);
    if (client_sock < 0)
    {
        perror("accept failed");
        return 1;
    }
    puts("Connection accepted");
     
    //Receive a message from client
    while( (read_size = recv(client_sock , &client_message[0] , 2000 , 0)) > 0 )
    {
	client_message[read_size]=0;
	msg=NULL;
	puts(client_message);
	if(strcmp(client_message,"on")==0)
	{
	 int r=0;
	 puts(client_message);
	 //switch(childpid=fork()){

		//case -1: printf("Error in fork"); return -1; break;

		//case 0: //Turn led on 
			    GPIOExport(POUT);
				//return(1);
			    GPIODirection(POUT, OUT);
				//return(2);
			    r = GPIOWrite(POUT,1);
			    //if(r==-1)
				//return(3);
				//break;
		//default: 
			 if(r>=0) msg="LED is on";
			 else {msg="Cannot turn LED on";} //break;
	
		//}
	}
        
        if(strcmp(client_message,"off")==0)
	{
	int r;
	 //switch(childpid=fork()){

		//case -1: printf("Error in fork"); return -1; break;

		//case 0:  
			 GPIOExport(POUT);

		   	 GPIODirection(POUT, OUT);
		   
		  	 r=GPIOWrite(POUT,0);//break;
		//default: 
			if(r>=0) msg="LED is off";
			 else {msg="Cannot turn LED off";} //break;
		//}
	}
        
       //Send the message back to client
	if(strcmp(client_message,"on")!=0 && strcmp(client_message,"off")!=0)
		msg="Unavailable Command";
        int c=send(client_sock , msg , strlen(msg),0);
	
	puts(client_message);
    }
     
   if(read_size == 0)
    {
        puts("Client disconnected");
        close(client_sock);
    }
   if(read_size == -1)
    {
        perror("recv failed");
    }
}
     
    return 0;

}
