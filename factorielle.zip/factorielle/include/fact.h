#ifndef LIB_FACT_H
#define LIB_FACT_H
    long long int factorielle(long int n);
#endif
