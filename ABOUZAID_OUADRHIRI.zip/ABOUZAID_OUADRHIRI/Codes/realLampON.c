
#include <stdio.h>

#include <gpioctrl.h>

int main(void) {
    
    GPIOExport(POUT);

    GPIODirection(POUT, OUT);
   
    GPIOWrite(POUT,1);
	

    printf("La Lampe est allumee");
    
    return 0;

}
