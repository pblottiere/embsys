
#include <stdio.h>

#include <gpioctrl.h>

int main(void) {
    
    GPIOExport(POUT);

    GPIODirection(POUT, OUT);
   
    GPIOWrite(POUT,0);
	

    printf("La Lampe est eteinte);
    
    return 0;

}
